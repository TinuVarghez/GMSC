package pack;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Register extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel lblUsername, lblPwd, lblType, lblImage,lblImage1,lblEC;
	JTextField txtUsername, txtPwd,txtEC;
	JComboBox<String> cb;
	JButton btnLogin, btnReg;
    String C[]={"User Type","Admin","Driver","User"}; 
    int o2;

	public void initWidget() {
		
		ImageIcon imgUser = new ImageIcon(getClass().getResource("/picture/user.jpeg"));
		Image imgResize = imgUser.getImage().getScaledInstance(626, 626, Image.SCALE_DEFAULT);
		ImageIcon imgUser2 = new ImageIcon(imgResize);
		lblImage = new JLabel(imgUser2);
		lblImage.setBounds(0, 0, 600, 600);
		add(lblImage);
		
		ImageIcon imgUser1 = new ImageIcon(getClass().getResource("/picture/s.png"));
		Image imgResize1 = imgUser1.getImage().getScaledInstance(250, 240, Image.SCALE_DEFAULT);
		ImageIcon imgUser3 = new ImageIcon(imgResize1);
		lblImage1 = new JLabel(imgUser3);
		lblImage1.setBounds(10, 10, 180, 180);
		lblImage.add(lblImage1);
		
		
		lblUsername = new JLabel("Enter Username");
		lblUsername.setBounds(200, 20, 100, 20);
		lblImage.add(lblUsername);
		
		txtUsername = new JTextField(15);
		txtUsername.setBounds(300, 20, 150, 20);
		lblImage.add(txtUsername);
		
		lblPwd = new JLabel("Enter Password");
		lblPwd.setBounds(200, 60, 100, 20);
		lblImage.add(lblPwd);
		
		txtPwd = new JTextField(15);
		txtPwd.setBounds(300, 60, 150, 20);
		lblImage.add(txtPwd);
		
		lblType = new JLabel("Register as");
		lblType.setBounds(200, 100, 100, 20);
		lblImage.add(lblType);
		
	    cb=new JComboBox<String>(C);    
		cb.setBounds(300, 100, 150, 20);
		lblImage.add(cb);
		cb.addActionListener(cb1->{ 
   		 o2=cb.getSelectedIndex();
   		 if(o2==1||o2==2)
   		 {
   			lblEC.setVisible(true);
   			txtEC.setVisible(true); 
   		 }
   		 else
   		 {
   			lblEC.setVisible(false);
   			txtEC.setVisible(false); 
   		 }
		});
		lblEC = new JLabel("Enter Code");
		lblEC.setBounds(200, 140, 100, 20);
		lblImage.add(lblEC);
		lblEC.setVisible(false);
		
		txtEC = new JTextField(15);
		txtEC.setBounds(300, 140, 150, 20);
		lblImage.add(txtEC);
		txtEC.setVisible(false);

		
		btnReg = new JButton("Register");
		btnReg.setBounds(350, 200, 110, 25);
		lblImage.add(btnReg);
		btnReg.addActionListener(this);
		
	}
	
	Register() {
		super("Register");
		initWidget();
		getContentPane().setBackground(Color.white);		
		setLayout(new BorderLayout());
		setSize(600, 600);
		setLocation(400, 100);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Register();
    }
	public void actionPerformed(ActionEvent e) {
		try {
			String n=txtUsername.getText(),p=txtPwd.getText();
            //register JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //establish the connection
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
            Statement st = con.createStatement();
          if(e.getSource()==btnReg)
	     {
        	    ResultSet rs = st.executeQuery("SELECT * from up where un='"+n+"'or pwd='"+p+"'");
        	    if(rs.next()==false)
        	    {
		 String num=txtEC.getText();
		 if(o2==3)
		 {
			    JOptionPane.showMessageDialog(null,"Sucessfully Created");	
				dispose();
				new Login();
			    st.executeUpdate("INSERT INTO up(un,pwd,mde)VALUES ('" + n + "','" + p + "','User')");
		        con.close();
     	 }
		 else {
		          if(num.equals("123"))
		          {
		          if(o2==1)
				  st.executeUpdate("INSERT INTO up(un,pwd,mde)VALUES ('" + n + "','" + p + "','Admin')");  
		          else
				  st.executeUpdate("INSERT INTO up(un,pwd,mde)VALUES ('" + n + "','" + p + "','Driver')");    
				  con.close();
			      JOptionPane.showMessageDialog(null,"Sucessfully Created");	
			      dispose();
			      new Login();
		          }
		          else
		          {
			      JOptionPane.showMessageDialog(null,"Incorrect Code");	
		          }
		     }
        	    }
        	    else
        	    	{
  			      JOptionPane.showMessageDialog(null,"Already Exists");	
        	    	}
        	    	}
		} catch (Exception e1) {
            System.err.println("Got an exception! ");
            System.err.println(e1.getMessage());
        }
	}
}

