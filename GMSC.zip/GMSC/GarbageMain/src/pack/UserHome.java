package pack;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class UserHome extends JFrame implements ActionListener  {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	JLabel lblUsername,lblImage;
	JButton btnCB, btnCC,btnCS,btnmsg,btnlog;
	
	public void initWidget(String Username) {

		ImageIcon imgUser = new ImageIcon(getClass().getResource("/picture/user.png"));
		Image imgResize = imgUser.getImage().getScaledInstance(700, 700, Image.SCALE_DEFAULT);
		ImageIcon imgUser2 = new ImageIcon(imgResize);
		lblImage = new JLabel(imgUser2);
		lblImage.setBounds(0, 0, 600, 600);
		add(lblImage);
		
		btnlog = new JButton("Logout");
		btnlog.setBounds(400, 10, 180, 40);
		btnlog.setBorderPainted(false);
        btnlog.setContentAreaFilled(false);
        btnlog.setFocusPainted(false);
		btnlog.setForeground(Color.WHITE);
		lblImage.add(btnlog);
		btnlog.addActionListener(this);
	    lblUsername = new JLabel("Welcome,"+Username);
		lblUsername.setBounds(50, 40, 500, 50);
		lblUsername.setFont(new Font("MS Mincho", Font.BOLD, 20));
		lblUsername.setForeground(Color.WHITE);
		lblImage.add(lblUsername);
		btnCB = new JButton("Create Bin");
		btnCB.setBounds(200, 200, 150, 40);
		lblImage.add(btnCB);
		btnCB.addActionListener(this);
		btnCC = new JButton("Create Complaint");
		btnCC.setBounds(200, 250, 150, 40);
		lblImage.add(btnCC);
		btnCC.addActionListener(this);
		btnCC.setActionCommand(Username);
		btnCS = new JButton("Complaint Status");
		btnCS.setBounds(200, 300, 150, 40);
		lblImage.add(btnCS);
		btnCS.addActionListener(this);
		btnmsg = new JButton("Messages");
		btnmsg.setBounds(200, 350, 150, 40);
		lblImage.add(btnmsg);
		btnmsg.addActionListener(this);
		getContentPane().setBackground(Color.white);		
		setLayout(new BorderLayout());
		setTitle("User");
		setSize(600, 600);
		setLocation(400, 100);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		dispose();
    	JFrame j = new JFrame("Create");
        j.setSize(600,600);
		j.setLocation(400, 100);
		j.setLayout(null);
        j.setVisible(true);
        JPanel p1=new JPanel();
        
        if(e.getSource()==btnCB)
        {
        	
        	JLabel bn = new JLabel("Enter Bin Number");
    		bn.setBounds(25, 30, 180, 40);
        	p1.add(bn);
        	JTextField txtbn = new JTextField(15);
    		txtbn.setBounds(140,40, 150, 20);
    		p1.add(txtbn);
        	JLabel loc = new JLabel("Enter location");
    		loc.setBounds(25, 60, 180, 40);
        	p1.add(loc);
        	JTextField txtloc = new JTextField(15);
    		txtloc.setBounds(140,70, 150, 20);
    		p1.add(txtloc);
    		JLabel c = new JLabel("Enter City");
    		c.setBounds(25, 90, 180, 40);
        	p1.add(c);
        	JTextField txtc = new JTextField(15);
    		txtc.setBounds(140,100, 150, 20);
    		p1.add(txtc);
    		JButton btnC = new JButton("Create");
    		btnC.setBounds(25, 150, 100, 20);
    		p1.add(btnC);
    		
    		btnC.addActionListener(cb->{
    			try {
    			String n=txtbn.getText(),l=txtloc.getText(),city=txtc.getText();
    			txtbn.setText("");
    			txtloc.setText("");
    			txtc.setText("");
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement st = con.createStatement();	
                st.executeUpdate("INSERT INTO bin(binno,loc,city,creator,approve)VALUES ('" + n + "','" + l + "','"+city+"','User','No')");
    	        con.close();
    			}
    			catch (Exception e1) {
                    System.err.println("Got an exception! ");
                    System.err.println(e1.getMessage());
    			 }
    		});
    		p1.setLayout(null);
            j.setContentPane(p1);
        }
        if(e.getSource()==btnCC)
        {
        	JLabel bn = new JLabel("Complaint Box");
    		bn.setBounds(105, 5, 180, 40);
        	p1.add(bn);
        	Random random = new Random();
            int sn = random.nextInt(9000) + 1000; 
        	JLabel cno = new JLabel("Complaint no: "+sn);
    		cno.setBounds(45, 50, 180, 40);
        	p1.add(cno);
        	JLabel c = new JLabel("Category:");
    		c.setBounds(45, 90, 180, 40);
        	p1.add(c);
        	String C[]={"Choose","Bin","Driver","Other"}; 
    		JComboBox<String> cb=new JComboBox<String>(C);   
    		cb.setBounds(150,100, 150, 20);
    		p1.add(cb);
        	JTextField o = new JTextField(15);
    		o.setBounds(150,135, 150, 20);
    		p1.add(o);
    		o.setVisible(false);
      		cb.addActionListener(c1->{
      			int i=cb.getSelectedIndex();
      			if(i==3)
      			{
      	    		o.setVisible(true);
      			}
      			else
      			{
      	    		o.setVisible(false);
      			}
      		});
      		JLabel con = new JLabel("Contact Number:");
    		con.setBounds(45, 165, 180, 40);
        	p1.add(con);
        	JTextField txtco = new JTextField(15);
    		txtco.setBounds(150,175, 150, 20);
    		p1.add(txtco);
        	JLabel des = new JLabel("Description:");
    		des.setBounds(45, 200, 180, 40);
        	p1.add(des);

      		JTextArea txta = new JTextArea();
    		txta.setBounds(150,205, 150, 100);
    		p1.add(txta);
    		
    		JButton Sub = new JButton("Submit");
    		Sub.setBounds(200, 350, 100, 20);
    		p1.add(Sub);
    		
    		Sub.addActionListener(S->{
    			try {
    			String d=txta.getText(),cont=txtco.getText(),cat=(String) cb.getSelectedItem(),oq=o.getText();
    			String Username=e.getActionCommand();
    			txta.setText("");
    			txtco.setText("");
    			o.setText("");
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement st = conn.createStatement();	
                st.executeUpdate("INSERT INTO complaint(category,des,cno,creator,sno,reply)VALUES ('" + cat +"\n\n"+ oq + "','" + d + "',"+cont+",'"+Username+"(User)',"+sn+",'SOON')");
            	JOptionPane.showMessageDialog(null, "Complaint Registered Sucessfully\nYou can track on 'Complaint Status' as "+sn);
                conn.close();
    			}
    			catch (Exception e1) {
                    System.err.println("Got an exception! ");
                    System.err.println(e1.getMessage());
    			}
    		});
    		p1.setLayout(null);
            j.setContentPane(p1);	
        }
        if(e.getSource()==btnCS)
        {
        	JLabel bn = new JLabel("Complaint Tracker");
    		bn.setBounds(105, 5, 180, 40);
        	p1.add(bn);
        	JLabel cn = new JLabel("Enter Complaint Number");
    		cn.setBounds(25, 60, 180, 40);
        	p1.add(cn);
        	JTextField txtcn = new JTextField(15);
    		txtcn.setBounds(180,70, 150, 20);
    		p1.add(txtcn);
    		JButton S = new JButton("Search");
    		S.setBounds(370, 70, 100, 20);
    		p1.add(S);
    		
    		S.addActionListener(S1->{
    			try {
    			String cno=txtcn.getText();
                String QUERY = "SELECT reply,category,des,creator FROM complaint where sno="+cno+" ";
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement st = conn.createStatement();	
                ResultSet rs = st.executeQuery(QUERY);
                if(rs.next())
                {
                	S.setVisible(false);
                	String reply=rs.getString("reply");
                    String category=rs.getString("category");
                    String des=rs.getString("des");
                    String cr=rs.getString("creator");
                    
                    JLabel cnoo = new JLabel("Complaint Number: "+cno);
            		cnoo.setBounds(25,90, 180, 40);
                	p1.add(cnoo);
                	JLabel c = new JLabel("Category: "+category);
            		c.setBounds(25, 120, 180, 40);
                	p1.add(c);
                	JLabel cr1 = new JLabel("Creator: "+cr);
            		cr1.setBounds(25, 140, 180, 40);
                	p1.add(cr1);
                	JLabel des1 = new JLabel("Description: "+des);
            		des1.setBounds(25, 160, 180, 40);
                	p1.add(des1);
                	JLabel r = new JLabel("Reply: "+reply);
            		r.setBounds(25, 180, 180, 40);
                	p1.add(r);
                	if(!reply.equals("SOON"))
                	{
                	JLabel rat = new JLabel("Rating");
            		rat.setBounds(25, 220, 180, 40);
                	p1.add(rat);
                	JRadioButton rb1 = new JRadioButton("1");
                	rb1.setBounds(25, 260, 40, 40);
                	p1.add(rb1);
                    JRadioButton rb2 = new JRadioButton("2");
                    rb2.setBounds(65, 260, 40, 40);
                	p1.add(rb2);
                    JRadioButton rb3 = new JRadioButton("3");
                    rb3.setBounds(105, 260, 50, 40);
                	p1.add(rb3);
                	JButton Cl = new JButton("Close Complaint");
            		Cl.setBounds(120, 350, 150, 20);
            		p1.add(Cl);
            		Cl.addActionListener(Cl1->{
                            try {
								st.executeQuery("Delete FROM complaint where sno="+cno+" ");

							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
                            dispose();
            		});  
                	}
                   j.setContentPane(p1);
                }
               else
                {
                	S.setVisible(true);
                	txtcn.setText("");
                	JOptionPane.showMessageDialog(null, "Incorrect number");
                	
                }
    			}catch (Exception e1) {
                    System.err.println("Got an exception! ");
                    System.err.println(e1.getMessage());
    			}
    		});
    		
    		p1.setLayout(null);
            j.setContentPane(p1);	
        }
        if(e.getSource()==btnmsg)
        {
        	j.setSize(700,600);
        	JPanel p=new JPanel();
        	DefaultTableModel dm = new DefaultTableModel();
            JTable table = new JTable(dm);
            table.setPreferredScrollableViewportSize(new Dimension(250, 250));
            table.setRowHeight(table.getRowHeight() + 50);
            JScrollPane SP= new JScrollPane(table);
    		SP.setBounds(15,10, 500,500);        
            p.add(SP);
            table.setEnabled(false);
            dm.addColumn("Sr No");
            dm.addColumn("Subject");
            dm.addColumn("Description");
            TableColumn column1 = table.getColumnModel().getColumn(0);
            column1.setPreferredWidth(50);

            // Adjust the size of column 2 (Description) to be smaller
            TableColumn column2 = table.getColumnModel().getColumn(1);
            column2.setPreferredWidth(200);
            TableColumn column3 = table.getColumnModel().getColumn(2);
            column3.setPreferredWidth(500);
            String QUERY = "SELECT * FROM msg where tr='User' or tr='All'";
            // Open a connection
            try {
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(QUERY);
                int i=0;
                while (rs.next()) {
                    String sub=rs.getString("subj");
                    String des=rs.getString("des");
                    
                        dm.addRow(new Object[]{i+1,sub,des});//Adding row in Table
                }
            }catch (Exception e1) {
                System.err.println("Got an exception! ");
                System.err.println(e1.getMessage());
    		 }
            p.setLayout(null);
 	       j.setContentPane(p);  

        }
        if(e.getSource()==btnlog)
        {
        dispose();
        j.dispose();
		new Login();
        }
	}
/*	public static void main(String args[])
	{
		UserHome a = new UserHome();
		a.initWidget("Tinu");
	}
*/
}
