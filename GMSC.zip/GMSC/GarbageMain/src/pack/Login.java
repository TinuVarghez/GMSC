package pack;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel lblUsername, lblPwd, lblType, lblImage;
	JTextField txtUsername, txtPwd;
	JComboBox<String> cb;
	JButton btnLogin, btnReg;
	String C[]={"User Type","Admin","Driver","User"}; 
    int o2;

	public void initWidget() {
		ImageIcon imgUser = new ImageIcon(getClass().getResource("/picture/s.png"));
		Image imgResize = imgUser.getImage().getScaledInstance(250, 240, Image.SCALE_DEFAULT);
		ImageIcon imgUser2 = new ImageIcon(imgResize);
		lblImage = new JLabel(imgUser2);
		lblImage.setBounds(0, 10, 180, 180);
		add(lblImage);
		
		
		lblUsername = new JLabel("Username");
		lblUsername.setBounds(200, 20, 100, 20);
		add(lblUsername);
		
		txtUsername = new JTextField(15);
		txtUsername.setBounds(300, 20, 150, 20);
		add(txtUsername);
		
		lblPwd = new JLabel("Password");
		lblPwd.setBounds(200, 60, 100, 20);
		add(lblPwd);
		
		txtPwd = new JTextField(15);
		txtPwd.setBounds(300, 60, 150, 20);
		add(txtPwd);
		
		lblType = new JLabel("Login as");
		lblType.setBounds(200, 100, 100, 20);
		add(lblType);

		cb=new JComboBox<String>(C);    
  		cb.setBounds(300, 100, 150, 20);
		add(cb);
		
		btnLogin = new JButton("Login");
		btnLogin.setBounds(200, 150, 110, 25);
		add(btnLogin);
		btnLogin.addActionListener(this);
		
		btnReg = new JButton("Register");
		btnReg.setBounds(350, 150, 110, 25);
		add(btnReg);
		btnReg.addActionListener(this);
		
		
	}
	
	Login() {
		super("Login");
		initWidget();
		getContentPane().setBackground(Color.white);		
		setLayout(new BorderLayout());
		setSize(600, 240);
		setLocation(400, 300);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Login();
    
	}
	public void actionPerformed(ActionEvent e) {
		 if(e.getSource()==btnReg)
		 {
			 dispose();
		     new Register();  
		 }
		 if(e.getSource()==btnLogin)
		 {   	
			 try {
		 
				String n=txtUsername.getText(),p=txtPwd.getText();
	            //register JDBC driver
	            Class.forName("oracle.jdbc.driver.OracleDriver");
	            //establish the connection
	            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
	            Statement st = con.createStatement();
	   		 o2=cb.getSelectedIndex();
	   		ResultSet rs = st.executeQuery("SELECT * from up where un='"+n+"'or pwd='"+p+"'");
    	    if(rs.next()==true)
    	    {
	   		 if(o2==1)
	   		 {
		   			AdminHome a = new AdminHome();
		   		 	 a.initWidget();
					 dispose();
	   		 }
	   		 else if(o2==2)
	   		 {
		   			DriverHome a = new DriverHome(); 
		   		 	 a.initWidget(n);
					 dispose();
	   		 }
	   		 else if(o2==3) 
	   		 {
	   			UserHome a = new UserHome();
	   		 	 a.initWidget(n);
				 dispose();
	   		 }
	   		 else
	   		 {
			      JOptionPane.showMessageDialog(null,"Not Selected");		 
	   		 }
			 }
    	    else
    	    {
			      JOptionPane.showMessageDialog(null,"Not Existing");		 	
    	    }
			 }catch (Exception e1) {
                System.err.println("Got an exception! ");
                System.err.println(e1.getMessage());
			 }
		 }

	}}
