package pack;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AdminHome extends JFrame implements ActionListener  {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	JLabel lblUsername,lblImage;
	JButton btnCB, btnUD,btnVC,btnmes,btnlog;
	
	public void initWidget() {

		ImageIcon imgUser = new ImageIcon(getClass().getResource("/picture/admin.jpeg"));
		Image imgResize = imgUser.getImage().getScaledInstance(800, 800, Image.SCALE_DEFAULT);
		ImageIcon imgUser2 = new ImageIcon(imgResize);
		lblImage = new JLabel(imgUser2);
		lblImage.setBounds(0, 10, 800, 600);
		add(lblImage);
		
		btnlog = new JButton("Logout");
		btnlog.setBounds(500, 10, 180, 40);
		btnlog.setBorderPainted(false);
        btnlog.setContentAreaFilled(false);
        btnlog.setFocusPainted(false);
		lblImage.add(btnlog);
		btnlog.addActionListener(this);
		
		lblUsername = new JLabel("Hi,Admin");
		lblUsername.setBounds(50, 20, 500, 50);
		lblUsername.setFont(new Font("MS Mincho", Font.BOLD, 20));
		lblImage.add(lblUsername);
		
		btnCB = new JButton("Bin");
		btnCB.setBounds(200, 200, 180, 40);
		lblImage.add(btnCB);
		btnCB.addActionListener(this);
				
		btnUD = new JButton("User & Driver Details");
		btnUD.setBounds(200, 250, 180, 40);
		lblImage.add(btnUD);
		btnUD.addActionListener(this);
		
		btnVC = new JButton("View Complaints");
		btnVC.setBounds(200, 300, 180, 40);
		lblImage.add(btnVC);
		btnVC.addActionListener(this);
				
		btnmes = new JButton("Send Message");
		btnmes.setBounds(200, 350, 180, 40);
		lblImage.add(btnmes);
		btnmes.addActionListener(this);
		
		
		getContentPane().setBackground(Color.white);		
		setLayout(new BorderLayout());
		setTitle("Administrator Panel");
		setSize(700, 650);
		setLocation(400, 100);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		JFrame j = new JFrame();
        j.setSize(600,600);
		j.setLocation(400, 100);
		j.setLayout(null);
        j.setVisible(true);

        if(e.getSource()==btnCB)
        {
        dispose();
        JTabbedPane tp = new JTabbedPane();
        JPanel p1=new JPanel();
        JPanel p2=new JPanel();
        
        tp.addTab("Crud", p1);
        tp.setMnemonicAt(0,KeyEvent.VK_1);
        JLabel bn = new JLabel("Enter Bin Number");
		bn.setBounds(25, 30, 180, 40);
    	p1.add(bn);
    	JTextField txtbn = new JTextField(15);
		txtbn.setBounds(140,40, 150, 20);
		p1.add(txtbn);
    	JLabel loc = new JLabel("Enter location");
		loc.setBounds(25, 60, 180, 40);
    	p1.add(loc);
    	JTextField txtloc = new JTextField(15);
		txtloc.setBounds(140,70, 150, 20);
		p1.add(txtloc);
		JLabel c = new JLabel("Enter City");
		c.setBounds(25, 90, 180, 40);
    	p1.add(c);
    	JTextField txtc = new JTextField(15);
		txtc.setBounds(140,100, 150, 20);
		p1.add(txtc);
		JButton btnC = new JButton("Create");
		btnC.setBounds(25, 150, 100, 20);
		p1.add(btnC);
		btnC.addActionListener(cb->{
			try {
			String n=txtbn.getText(),l=txtloc.getText(),city=txtc.getText();
			txtbn.setText("");
			txtloc.setText("");
			txtc.setText("");
            
            //register JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //establish the connection
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
            Statement st = con.createStatement();	
            st.executeUpdate("INSERT INTO bin(binno,loc,city,creator,approve)VALUES ('" + n + "','" + l + "','"+city+"','Admin','Yes')");
	        con.close();
			}
			catch (Exception e1) {
                System.err.println("Got an exception! ");
                System.err.println(e1.getMessage());
			 }
		});
		DefaultTableModel dm = new DefaultTableModel();
        JTable table = new JTable(dm);
        table.setPreferredScrollableViewportSize(new Dimension(650, 350));
        JScrollPane SP= new JScrollPane(table);
		SP.setBounds(25,200, 400,200);        
        p1.add(SP);
        table.setEnabled(false);
        dm.addColumn("Bin no");
        dm.addColumn("Location");
        dm.addColumn("City");
        dm.addColumn("Creator");
        String QUERY = "SELECT * FROM bin where approve='Yes'";
        // Open a connection
        try {
            //register JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //establish the connection
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);

            while (rs.next()) {
                //Display values
                String bn1=rs.getString("binno");
                String loca=rs.getString("loc");
                String city=rs.getString("city");
                String cr=rs.getString("creator");
                    dm.addRow(new Object[]{bn1,loca,city,cr});//Adding row in Table
            }
        }catch (Exception e1) {
            System.err.println("Got an exception! ");
            System.err.println(e1.getMessage());
		 }
        
        JButton s = new JButton("Save");
		s.setBounds(470, 300, 80, 30);
		p1.add(s);
		s.setVisible(false);
		
        JButton up = new JButton("Update");
		up.setBounds(100, 450, 80, 30);
		p1.add(up);
		up.addActionListener(u-> 
		table.addMouseListener(new MouseAdapter()
        {
        	public void mouseClicked (MouseEvent e) {
        table.setEnabled(true);
        s.setVisible(true);
        s.addActionListener(l -> {
        	try {
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement stmt = con.createStatement();

        	String bno,l2,c,cr;
            int j=table.getRowCount();
    	    stmt.executeQuery("truncate table bin");
        	for(int i=0;i<j;i++)
        	{
            	bno=(String) dm.getValueAt(i,0);
            	l2=(String) dm.getValueAt(i,1);
            	c=(String) dm.getValueAt(i,2);
            	cr=(String) dm.getValueAt(i,3);
                    stmt.executeQuery("INSERT INTO bin(binno,loc,city,creator,approve)VALUES ('" + bno + "','" + l2 + "','"+c+"','"+cr+"','Yes')");
               
        	}
        	 }catch (Exception e1) {
                 System.err.println("Got an exception! ");
                 System.err.println(e1.getMessage());
     		 }

            	JOptionPane.showMessageDialog(null, "Updated Successfully");
            
        });
        }
        }));
		
		JButton del = new JButton("Delete");
	    del.setBounds(250, 450,80, 30);
		p1.add(del);
		del.addActionListener(de->{
			table.addMouseListener(new MouseAdapter()
	        {
	        	public void mouseClicked (MouseEvent e) {
	                table.setEnabled(true);
	        		s.setVisible(true);
	                s.addActionListener(l -> {
	                int i=table.getSelectedRow();                	

	            	String bno=(String) dm.getValueAt(i,0);
	            	try {
	                    //register JDBC driver
	                    Class.forName("oracle.jdbc.driver.OracleDriver");
	                    //establish the connection
	                    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
	                    Statement stmt = con.createStatement();
	                    stmt.executeQuery("Delete from bin where binno='"+bno+"'");
	                }catch (Exception e1) {
	                    System.err.println("Got an exception! ");
	                    System.err.println(e1.getMessage());
	        		 }
                   
	                });
	        	}
		
	   });
		});
		
		
        p1.setLayout(null);
        
        tp.addTab("Approve", p2);
        tp.setMnemonicAt(1,KeyEvent.VK_1);
        DefaultTableModel dm1 = new DefaultTableModel();
        JTable table1 = new JTable(dm1);
        table1.setPreferredScrollableViewportSize(new Dimension(650, 350));
        JScrollPane SP1= new JScrollPane(table1);
		SP1.setBounds(25,10, 500,500);        
        p2.add(SP1);
        table1.setEnabled(false);
        JButton s1 = new JButton("Save");
		s1.setBounds(470, 300, 80, 30);
		p2.add(s1);
		s1.setVisible(false);
		String C[]={"Choose","Yes","No"}; 
		JComboBox<String> cb=new JComboBox<String>(C);    
  		dm1.addColumn("Bin no");
        dm1.addColumn("Location");
        dm1.addColumn("City");
        dm1.addColumn("Creator");
        dm1.addColumn("Approve");
        String QUERY1 = "SELECT * FROM bin where approve='No'";
        // Open a connection
        try {
            //register JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //establish the connection
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY1);
            while (rs.next()) {
                //Display values
            	String b1=rs.getString("binno");
                String la=rs.getString("loc");
                String ci=rs.getString("city");
                String c1=rs.getString("creator");
                
                    dm1.addRow(new Object[]{b1,la,ci,c1});//Adding row in Table
                    table1.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(cb));
            }
        }catch (Exception e1) {
            System.err.println("Got an exception! ");
            System.err.println(e1.getMessage());
		 }
        table1.addMouseListener(new MouseAdapter()
        {
        	public void mouseClicked (MouseEvent e) {
                table1.setEnabled(true);
        		s1.setVisible(true);
                s1.addActionListener(l -> {
                	int j=table1.getSelectedRow();
	            	String bno=(String) dm1.getValueAt(j,0);
	            	String choice=(String) dm1.getValueAt(j,4);
	            	
	            	try {
	                    //register JDBC driver
	                    Class.forName("oracle.jdbc.driver.OracleDriver");
	                    //establish the connection
	                    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
	                    Statement stmt = con.createStatement();
	                    if(choice.equals("Yes"))
		            	{
	                       stmt.executeQuery("Update bin set approve='Yes' where binno='"+bno+"'");
		            	}
	                    else if(choice=="No")
	                    {
		                    stmt.executeQuery("Delete from bin where binno='"+bno+"'");	
	                    }
	                    else
	                    {
	                    	JOptionPane.showMessageDialog(null, "Not Selected");	
	                    }
	                }catch (Exception e1) {
	                    System.err.println("Got an exception! ");
	                    System.err.println(e1.getMessage());
	        		 }
	            	
                });
        }
        });
        p2.setLayout(null);
        j.setContentPane(tp);
        }
        if(e.getSource()==btnUD)
        {
        	dispose();
            JTabbedPane tp1 = new JTabbedPane();
            JPanel p1=new JPanel();
            JPanel p2=new JPanel();
            
            tp1.addTab("User", p1);
            tp1.setMnemonicAt(0,KeyEvent.VK_1);
      		DefaultTableModel dm = new DefaultTableModel();
            JTable table = new JTable(dm);
            table.setPreferredScrollableViewportSize(new Dimension(650, 350));
            JScrollPane SP= new JScrollPane(table);
            table.setRowHeight(table.getRowHeight() + 20);
    		SP.setBounds(15,10, 500,500);        
            p1.add(SP);
            table.setEnabled(false);
            dm.addColumn("Sr no");
            dm.addColumn("Username");
            dm.addColumn("Password");
            //dm.addColumn("Creator");
            String QUERY = "SELECT * FROM up where mde='User'";
            // Open a connection
            try {
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(QUERY);
                int i=1;
                while (rs.next()) {
                    //Display values
                    String u=rs.getString("un");
                    String p=rs.getString("pwd");
                        dm.addRow(new Object[]{i,u,p});//Adding row in Table
                        i++;
                }
            }catch (Exception e1) {
                System.err.println("Got an exception! ");
                System.err.println(e1.getMessage());
    		 }
            
            p1.setLayout(null);
            
            tp1.addTab("Driver", p2);
            tp1.setMnemonicAt(1,KeyEvent.VK_1);
            DefaultTableModel dm1 = new DefaultTableModel();
            JTable table1 = new JTable(dm1);
            table1.setPreferredScrollableViewportSize(new Dimension(650, 450));
            JScrollPane SP1= new JScrollPane(table1);
            table1.setRowHeight(table.getRowHeight() + 20);
    		SP1.setBounds(15,10, 500,500);        
            p2.add(SP1);
            table.setEnabled(false);
            dm1.addColumn("Sr no");
            dm1.addColumn("Username");
            dm1.addColumn("Password");
            //dm.addColumn("Creator");
            String QUERY1 = "SELECT * FROM up where mde='Driver'";
            // Open a connection
            try {
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(QUERY1);
                int i=1;
                while (rs.next()) {
                    //Display values
                    String u=rs.getString("un");
                    String p=rs.getString("pwd");
                        dm1.addRow(new Object[]{i,u,p});//Adding row in Table
                        i++;
                }
            }catch (Exception e1) {
                System.err.println("Got an exception! ");
                System.err.println(e1.getMessage());
    		 }
            
            p2.setLayout(null);
         
            j.setContentPane(tp1);
            	
        }
        if(e.getSource()==btnVC)
        {
        	j.setSize(700,600);
        	JPanel p=new JPanel();
        	DefaultTableModel dm = new DefaultTableModel();
            JTable table = new JTable(dm);
            table.setPreferredScrollableViewportSize(new Dimension(250, 250));
            table.setRowHeight(table.getRowHeight() + 50);
            JScrollPane SP= new JScrollPane(table);
    		SP.setBounds(15,10, 500,500);        
            p.add(SP);
            table.setEnabled(false);
            dm.addColumn("Complaint No");
            dm.addColumn("Category");
            dm.addColumn("Description");
            dm.addColumn("By");
            dm.addColumn("Contact No");
            dm.addColumn("Reply");
            String QUERY = "SELECT * FROM complaint";
            // Open a connection
            try {
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(QUERY);

                while (rs.next()) {
                    String reply=rs.getString("reply");
                    String sn=rs.getString("sno");
                    String category=rs.getString("category");
                    String des=rs.getString("des");
                    String cno=rs.getString("cno");
                    String cr=rs.getString("creator");
                    if(reply.equals("SOON"))
                    {
                        dm.addRow(new Object[]{sn,category,des,cr,cno});//Adding row in Table
                    }
                }
            }catch (Exception e1) {
                System.err.println("Got an exception! ");
                System.err.println(e1.getMessage());
    		 }
            
            JButton s = new JButton("Save");
    		s.setBounds(550, 330, 80, 30);
    		p.add(s);
    		s.setVisible(false);
    		table.addMouseListener(new MouseAdapter()
            {
            	public void mouseClicked (MouseEvent e) {
                    table.setEnabled(true);
            		s.setVisible(true);
                    s.addActionListener(l -> {
                    	int j=table.getSelectedRow();
    	            	String sn=(String) dm.getValueAt(j,0);
    	            	String reply=(String) dm.getValueAt(j,5);
    	            	
    	            	try {
    	                    //register JDBC driver
    	                    Class.forName("oracle.jdbc.driver.OracleDriver");
    	                    //establish the connection
    	                    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
    	                    Statement stmt = con.createStatement();
    	                    
    	                       stmt.executeQuery("Update complaint set reply='"+reply+"' where sno='"+sn+"'");
    		            
    	                    
    	                }catch (Exception e1) {
    	                    System.err.println("Got an exception! ");
    	                    System.err.println(e1.getMessage());
    	        		 }
    	            	
                    });
            }
            });
            

    		p.setLayout(null);
	       j.setContentPane(p);
        }
        
        if(e.getSource()==btnmes)
        {
        	dispose();
        	JPanel p1=new JPanel();
        	JLabel bn = new JLabel("Message Center");
    		bn.setBounds(105, 5, 180, 40);
        	p1.add(bn);
        	JLabel c = new JLabel("Subject:");
    		c.setBounds(45, 90, 180, 40);
        	p1.add(c);
        	
        	JTextField o = new JTextField(15);
    		o.setBounds(150,100, 150, 20);
    		p1.add(o);
    		o.setVisible(true);
    		JLabel snt = new JLabel("Transfer to:");
    		snt.setBounds(45, 140, 180, 40);
        	p1.add(snt);
    		String C[]={"Choose","User","Driver","All"}; 
    		JComboBox<String> cb=new JComboBox<String>(C);   
    		cb.setBounds(150,150, 150, 20);
    		p1.add(cb);
      		
        	JLabel des = new JLabel("Description:");
    		des.setBounds(45, 190, 180, 40);
        	p1.add(des);

      		JTextArea txta = new JTextArea();
    		txta.setBounds(150,200, 150, 100);
    		p1.add(txta);
    		
    		JButton Sub = new JButton("Submit");
    		Sub.setBounds(200, 320, 100, 20);
    		p1.add(Sub);
    		
    		Sub.addActionListener(S->{
    			try {
    			String d=txta.getText(),tt=(String) cb.getSelectedItem(),oq=o.getText();
    			txta.setText("");
    			o.setText("");
                //register JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");
                //establish the connection
                Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
                Statement st = conn.createStatement();	
                st.executeUpdate("INSERT INTO msg(subj,des,tr)VALUES ('" + oq +"','"+ d + "','"+tt+"')");
                conn.close();
    			}
    			catch (Exception e1) {
                    System.err.println("Got an exception! ");
                    System.err.println(e1.getMessage());
    			}
    		});
    		p1.setLayout(null);
            j.setContentPane(p1);	
        
	
        }
        if(e.getSource()==btnlog)
        {
        dispose();
        j.dispose();
		new Login();
        }
	}
	public static void main(String args[])
	{
		AdminHome a = new AdminHome();
		a.initWidget();
	}

}
