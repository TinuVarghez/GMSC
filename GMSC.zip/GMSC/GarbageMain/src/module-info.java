module GarbageMain {
	requires java.desktop;
	requires java.sql;
}